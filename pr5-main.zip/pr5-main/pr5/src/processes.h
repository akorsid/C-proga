#ifndef PROCESSES_H
#define PROCESSES_H

void listProcesses();

#endif
