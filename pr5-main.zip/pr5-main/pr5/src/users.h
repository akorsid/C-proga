#ifndef USERS_H
#define USERS_H

void listUsers();

#endif
