#ifndef LOG_H
#define LOG_H

void redirectOutputToLog(char *path);

#endif
