#ifndef HELP_H
#define HELP_H

void printUsage();

#endif
