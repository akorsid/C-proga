#ifndef ERROR_H
#define ERROR_H

void redirectErrorsToLog(char *path);

#endif
